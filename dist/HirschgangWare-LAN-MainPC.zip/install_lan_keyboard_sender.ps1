[CmdletBinding()]
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'HirschgangWareInput'
$exe = Join-Path $target 'HirschgangWare-InputSender.exe'
$shortcut = Join-Path ([Environment]::GetFolderPath('Startup')) 'HirschgangWare LAN Keyboard.lnk'

if (!$Uninstall) {
    foreach ($name in @('HirschgangWare-InputSender.exe', 'lan-keyboard-sender.ini')) {
        if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $name))) { throw "Missing $name in the Main-PC package." }
    }
}
Get-Process -Name 'HirschgangWare-InputSender' -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -eq $exe -and $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
    Stop-Process -ErrorAction Stop
if ($Uninstall) {
    if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut }
    return
}

New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'HirschgangWare-InputSender.exe') -Destination $exe -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'lan-keyboard-sender.ini') -Destination $target -Force
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($shortcut)
$link.TargetPath = $exe
$link.WorkingDirectory = $target
$link.Description = 'Send the configured HirschgangWare hotkeys over LAN'
$link.Save()
Start-Process -FilePath $exe -WorkingDirectory $target -WindowStyle Hidden
Write-Output 'LAN input sender started and registered for Windows sign-in.'
