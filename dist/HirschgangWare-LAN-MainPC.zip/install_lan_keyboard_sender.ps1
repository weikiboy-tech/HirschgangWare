[CmdletBinding()]
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'HirschgangWareInput'
$exe = Join-Path $target 'HirschgangWare-InputSender.exe'
$sourceExe = Join-Path $PSScriptRoot 'HirschgangWare-InputSender.exe'
$sourceIni = Join-Path $PSScriptRoot 'lan-keyboard-sender.ini'
$installedIni = Join-Path $target 'lan-keyboard-sender.ini'
$shortcut = Join-Path ([Environment]::GetFolderPath('Startup')) 'HirschgangWare LAN Keyboard.lnk'

if (!$Uninstall) {
    if (!(Test-Path -LiteralPath $sourceExe)) { throw 'Missing HirschgangWare-InputSender.exe in the Main-PC package.' }
    if (!(Test-Path -LiteralPath $sourceIni) -and !(Test-Path -LiteralPath $installedIni)) {
        throw 'Missing private lan-keyboard-sender.ini. Put the pairing file next to the installer.'
    }
}
Get-Process -Name 'HirschgangWare-InputSender' -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -eq $exe -and $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
    Stop-Process -ErrorAction Stop
if ($Uninstall) {
    if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut }
    return
}

New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item -LiteralPath $sourceExe -Destination $exe -Force
if (Test-Path -LiteralPath $sourceIni) { Copy-Item -LiteralPath $sourceIni -Destination $installedIni -Force }
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($shortcut)
$link.TargetPath = $exe
$link.WorkingDirectory = $target
$link.Description = 'Send the configured HirschgangWare hotkeys over LAN'
$link.Save()
Start-Process -FilePath $exe -WorkingDirectory $target -WindowStyle Hidden
Write-Output 'LAN input sender started and registered for Windows sign-in.'
